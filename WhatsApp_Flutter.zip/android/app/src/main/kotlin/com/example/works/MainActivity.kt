package com.example.works

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
