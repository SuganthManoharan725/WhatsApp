class CallModel {
  final String name;
  final String time;
  final String pic;

  CallModel(this.name, this.time, this.pic);
}

List<CallModel> callData = [
  new CallModel("Hitana", "Just Now",
      "https://images.alphacoders.com/135/thumb-440-135673.webp"),
  new CallModel("kakashi Sensei", "09.10 AM",
      "https://images8.alphacoders.com/644/thumb-440-644172.webp"),
  new CallModel("Jiraya", "11.25 PM",
      "https://images3.alphacoders.com/644/thumb-440-644170.webp"),
  new CallModel("Granny", "10.52 PM",
      "https://images2.alphacoders.com/772/thumb-440-772879.webp"),
  new CallModel("Shikamaru", "08.19 PM",
      "https://images2.alphacoders.com/644/thumb-440-644187.webp"),
  new CallModel("Lee", "03.30 PM",
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSw_8SDGzO2-lDP7z5xf2k_N-P0QZtL_Dkqg&usqp=CAU"),
];
