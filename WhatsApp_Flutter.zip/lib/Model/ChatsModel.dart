class ChatModel {
  final String name;
  final String msg;
  final String time;
  final String pic;

  ChatModel(this.name, this.msg, this.time, this.pic);
}

List<ChatModel> chatsData = [
  new ChatModel("Hitana", "Naruto...❤️️❤️️! ", "Just Now",
      "https://images.alphacoders.com/135/thumb-440-135673.webp"),
  new ChatModel("Sasuke", "Where Are you? Idiot", "09.20 AM",
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSH6tYRQJOiDSMUe3liPVuklaKjXlibJP2a8Q&usqp=CAU"),
  new ChatModel("kakashi Sensei", "Come to Training Ground", "09.08 AM",
      "https://images8.alphacoders.com/644/thumb-440-644172.webp"),
  new ChatModel("Sakura", "Idiot! are u Awake?", "8.40 AM",
      "https://www.redwolf.in/image/cache/catalog/posters/team-7-sensei-poster-india-584x779.jpg"),
  new ChatModel("Itachi Brother", "Are you instrested to learn genjutsu",
      "07.17 AM", "https://images3.alphacoders.com/644/thumb-440-644161.webp"),
  new ChatModel("Jiraya Sensei", "What to eat at night?", "11.30 PM",
      "https://images3.alphacoders.com/644/thumb-440-644170.webp"),
  new ChatModel("Granny", "Why dont you report about mission?", "10.49 PM",
      "https://images2.alphacoders.com/772/thumb-440-772879.webp"),
  new ChatModel("Neji", "Where is my sister?", "08.30 PM",
      "https://images7.alphacoders.com/100/1008846.png"),
  new ChatModel("Shikamaru", "Can we go Ichiraku shop", "07.53 PM",
      "https://images2.alphacoders.com/644/thumb-440-644187.webp"),
  new ChatModel("Choji", "bro!", "04.38 PM",
      "https://images5.alphacoders.com/105/thumb-440-1054214.webp"),
  new ChatModel("Shino", "good", "03.30 PM",
      "https://images3.alphacoders.com/644/thumbbig-644166.webp"),
  new ChatModel("Lee", "Im in training!", "01.27 PM",
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSw_8SDGzO2-lDP7z5xf2k_N-P0QZtL_Dkqg&usqp=CAU"),
  new ChatModel("Ino", "Did you see Sasuke", "12.15 PM",
      "https://images6.alphacoders.com/644/thumbbig-644195.webp"),
];
